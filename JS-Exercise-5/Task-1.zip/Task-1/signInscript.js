let form = document.getElementById('form');
form.addEventListener('submit',function(e){
    e.preventDefault();
})

let email = document.getElementById('email');
let password = document.getElementById('password');

let signInBtn = document.getElementById('signInButton');
signInBtn.addEventListener('click',handleSignIn);

function handleSignIn(){
    let studentArr = JSON.parse(localStorage.getItem('student'));
    let adminArr = JSON.parse(localStorage.getItem('admin'));

    let newArr = [...adminArr,...studentArr];
    console.log(newArr)

    let userCheck= newArr.find((obj)=>obj.emailId==email.value && obj.pass==password.value);
    console.log(userCheck);

    if(userCheck){
        if(userCheck.userRole=='admin'){
            window.location.href='adminDashboard.html';
        }
        else{
            window.location.href='studentDashboard.html';
        }
    }
    else{
        alert("Incorrect email or password");
    }
}
